package lumohacks.kaku;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Location;
import android.os.Handler;
import android.support.annotation.IntegerRes;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.widget.ViewAnimator;
import android.widget.ViewFlipper;
import android.widget.ViewSwitcher;

import org.w3c.dom.Text;

import java.io.FileInputStream;
import java.io.FileOutputStream;

public class MainActivityKaku extends AppCompatActivity {

    /* Global Variables*/
    final float[] initialKakuParameters = {0, 100, 0, 0};    /* Stores Evolution, Care, Currency, Objective */
    final String fileName = "kakuConfig.txt";

    float[] presentkakuParameters = {};
    String finalKakuParameters = "";
    String kakuName = "";

    private ViewAnimator VF;
    int[] images = {R.drawable.kaku_egg, R.drawable.dog1};

    public Button menuButton;
    public ImageSwitcher switchImage1;
    public ImageSwitcher switchImage2;
    public Button resetButton;

    public Text evolution;
    public Text care;
    public Text currency;
    public Text objectives;
    float image = 0;

    //ViewAnimator viewAnimator;


    /* Main Activity */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_kaku);

        startUp();
        menuNavigation();
        statistics();
        //mainGame();

    }



    /* Menu Navigation */
    public void menuNavigation() {
        menuButton = (Button) findViewById(R.id.menuButton);

        menuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent openMenu = new Intent(MainActivityKaku.this, MenuActivityKaku.class);
                startActivity(openMenu);
            }
        });
    }

    /* Read Data */
    public String readFile(String file)
    {
        String configContents = "";

        try{
            FileInputStream fis = openFileInput(file);
            int sizeOfFile = fis.available();
            byte[] buffer = new byte[sizeOfFile];
            fis.read(buffer);
            fis.close();
            configContents = new String(buffer);
            showToast("Reading Successful");
            showToast(configContents);
        }catch(Exception e)
        {
            e.printStackTrace();
            showToast("Reading Failed");
        }

        return configContents;
    }

    /* Save Data */
    public void saveFile(String file, String configContents)
    {
        try {
            FileOutputStream fos = openFileOutput(file, Context.MODE_PRIVATE);
            fos.write(configContents.getBytes());
            fos.close();
            showToast("Saving Successful");
            showToast(configContents);
        } catch (Exception e) {
            e.printStackTrace();
            showToast("Saving Failed");
        }
    }

    /* Show Toast */
    public void showToast(String text)
    {
        Toast.makeText(getApplicationContext(), text,Toast.LENGTH_LONG).show();
        return;
    }

    /* Load Data*/
    public void startUp()
    {
        String configContents = readFile(fileName);
        //String configContents = "";

        /* Sets up new game */
        if(configContents == "") {
            presentkakuParameters = initialKakuParameters;

            finalKakuParameters = String.valueOf(presentkakuParameters[0]) + " " + String.valueOf(presentkakuParameters[1]) + " " + String.valueOf(presentkakuParameters[2]) + " " + String.valueOf(presentkakuParameters[3]);
            saveFile(fileName, finalKakuParameters);


            imageSwitch(0);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        kakuNamePrompt("Congratulations, you have just adopted your very own Kaku! Let's start off by giving your Kaku a name!", "Next");
                    }
                }, 5000);
            }
        else
        {
            //mainGame();
            imageSwitch(1);
            return;
        };
    }

    public void imageSwitch(int image) {

        VF = (ViewAnimator)findViewById(R.id.viewAnimator1);

        for (int i = 0; i < images.length; i++) {
            ImageView imageView = new ImageView(getApplicationContext());
            imageView.setImageResource(images[i]);
            VF.addView(imageView);
        }

        final Animation inAnim = AnimationUtils.loadAnimation(this, R.anim.fade_in);
        final Animation outAnim = AnimationUtils.loadAnimation(this, R.anim.fade_out);

        VF.setInAnimation(inAnim);
        VF.setOutAnimation(outAnim);

        if(image == 0)
        {
            VF.setDisplayedChild(1);
            VF.showNext();
        }else
        {
            VF.setDisplayedChild(0);
            VF.showNext();
        }
    }

    /* Kaku Name Prompt Dialogue */
    public void kakuNamePrompt(String alertDialogMessage, String alertConfirmMessage)
    {
        AlertDialog.Builder myAlert = new AlertDialog.Builder(this);
        myAlert.setMessage(alertDialogMessage)
                .setPositiveButton(alertConfirmMessage, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivityKaku.this);
                        builder.setTitle("What is your Kaku's name:");

                        // Set up the input
                        final EditText input = new EditText(MainActivityKaku.this);

                        // Specify the type of input expected; this, for example, sets the input as a password, and will mask the text
                        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_NORMAL);
                        builder.setView(input);

                        // Set up the buttons
                        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                kakuName = input.getText().toString();
                                finalKakuParameters = finalKakuParameters + " " + kakuName;
                                saveFile(fileName, finalKakuParameters);
                                saveFile("kakuName.txt", kakuName);
                                imageSwitch(1);
                                //imageChange2();
                            }
                        });
                        builder.show();
                    }}
                )
                .create();
        myAlert.show();
    }

    /* Change Image*/

//    public void imageChange()
//    {
//        switchImage1 = (ImageSwitcher) findViewById(R.id.imageSwitcher2);
//        switchImage1.setFactory(new ViewSwitcher.ViewFactory() {
//            @Override
//            public View makeView() {
//                ImageView imageView = new ImageView(getApplicationContext());
//                imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
//                return imageView;
//            }
//        });
//            switchImage1.setImageResource(R.drawable.kaku_egg);}
//
//    public void imageChange2()
//    {
//        switchImage2 = (ImageSwitcher) findViewById(R.id.imageSwitcher1);
//        switchImage2.setFactory(new ViewSwitcher.ViewFactory() {
//            @Override
//            public View makeView() {
//                ImageView imageView = new ImageView(getApplicationContext());
//                imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
//                return imageView;
//            }
//        });
//            switchImage2.setImageResource(R.drawable.dog1);
//        }

        //testPictureButton.setImageResource(R.drawable.dog1);




    /* Main Game */
//    public void mainGame()
//    {
//        readFile("kakuConfigNew.txt");
//
//
//
//        return;
//    }

    public void statistics(){

        //EditText text1 = (EditText) findViewById(R.id.evolution_text);
        //text1.setText("Evolution Status: test");
        String data = readFile("kakuConfig.txt");
        if(data == "")
        {
            return;
        }
        String data1 = readFile("kakuConfigNew.txt");
        if(data1 == "")
        {
            return;
        }
        String[] splited2 = data1.split(" ");
        String[] splited = data.split(" ");
        String kName = readFile("kakuName.txt");

//        int currency1 = Integer.parseInt(splited2[2]);
//        int objective1 = Integer.parseInt(splited2[3]);
//        int currency2 = Integer.parseInt(splited[0]);
//        int objective2 = Integer.parseInt(splited[1]);
//
       // int in = Integer.valueOf(splited2[2]);

//        int currency1 = Integer.valueOf(splited2[2]);
//        int objective1 = Integer.valueOf(splited2[3]);
//        int currency2 = Integer.valueOf(splited[0]);
//        int objective2 = Integer.valueOf(splited[1]);
//
//        String currencynum = splited2[2] + splited[0];
//        int objectivenum = splited2[3] + splited[1])
//
//        int currencynum = currency1 + currency2;
//        int objectivenum = objective1 + objective2;
//
//
//        String evolutionst = "";
//
//        if (objectivenum > 5)
//        {
//             evolutionst = "1";
//        }else
//        {
//            evolutionst = "0";
//        }

//            if (splited[] == 0) {
//                evolution.setTextContent("Child");
//            } else if (presentkakuParameters[0] == 1) {
//                evolution.setTextContent("Teen");
//            }

        EditText kakuN = (EditText) findViewById(R.id.kaku_name);
        kakuN.setText(kName);

        EditText currency = (EditText) findViewById(R.id.currency_text);
        currency.setText("Currency Count: " + splited2[0]);


        EditText objectives = (EditText) findViewById(R.id.objectives_text);
        objectives.setText("Objectives Completed: " + splited2[1]);

        EditText evolution = (EditText) findViewById(R.id.evolution_text);
        evolution.setText("Evolution Stage: 0");

        EditText care = (EditText) findViewById(R.id.care_text);
        care.setText("Care Level: 100");

    }
    public void resetButton()
    {
        resetButton = (Button)findViewById(R.id.reset_Button);

        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String reset = "";

                saveFile(fileName, reset);
                saveFile("kakuConfigNew.txt", reset);
                saveFile("kakuName.txt", reset);
            }
        });
    }

}
