package lumohacks.kaku;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SettingsActivity extends AppCompatActivity {
    public Button returnButton;
    public Button resetButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        returnButton();
        //resetButton();
    }

    public void returnButton()
    {
        returnButton = (Button)findViewById(R.id.settingsButton);

        returnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent returnScreen = new Intent(SettingsActivity.this,MenuActivityKaku.class);
                startActivity(returnScreen);
            }
        });
    }

    public void resetButton(String alertDialogMessage) {
        AlertDialog.Builder myAlert = new AlertDialog.Builder(this);
        myAlert.setMessage(alertDialogMessage)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //kakuParameters = "";
                                //saveFile(fileName, kakuParameters);
                            }
                        }
                )
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        }
                )
                .create();
        myAlert.show();
    }



}
