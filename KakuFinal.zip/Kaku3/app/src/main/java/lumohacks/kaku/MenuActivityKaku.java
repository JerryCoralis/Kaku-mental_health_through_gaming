package lumohacks.kaku;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MenuActivityKaku extends AppCompatActivity {
    public Button returnButton;
    public Button objectivesButton;
    public Button statsButton;
    public Button settingsButton;
    public Button walkButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        ReturnPressed();
        ObjectivesPressed();
        //StatsPressed();
        SettingsPressed();
        WalkPressed();

    }


    public void ObjectivesPressed()
    {
        objectivesButton = (Button)findViewById(R.id.objectivesButton);

        objectivesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent objectiveScreen = new Intent(MenuActivityKaku.this,ObjectivesActivity.class);
                startActivity(objectiveScreen);
            }
        });
    }
    public void ReturnPressed()
    {
        returnButton = (Button)findViewById(R.id.returnButton);

        returnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent returnScreen = new Intent(MenuActivityKaku.this,MainActivityKaku.class);
                startActivity(returnScreen);
            }
        });
    }
//    public void StatsPressed()
//    {
//        statsButton = (Button)findViewById(R.id.statsButton);
//
//        statsButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                Intent statsScreen = new Intent(MenuActivityKaku.this,StatsActivity.class);
//                startActivity(statsScreen);
//            }
//        });
//    }
    public void SettingsPressed()
    {
        settingsButton = (Button)findViewById(R.id.settingsButton);

        settingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent settingScreen = new Intent(MenuActivityKaku.this,SettingsActivity.class);
                startActivity(settingScreen);
            }
        });
    }
    public void WalkPressed()
    {
        walkButton = (Button)findViewById(R.id.walkButton);

        walkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent GPSScreen = new Intent(MenuActivityKaku.this,GPS.class);
                startActivity(GPSScreen);
            }
        });
    }

//    /* Setup GPS */
//    public void GPS() {
//        btnGetLoc = (Button) findViewById(R.id.btnGetLoc);
//        ActivityCompat.requestPermissions(MenuActivityKaku.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},123);
//        btnGetLoc.setOnClickListener(new View.OnClickListener(){
//            @Override
//            public void onClick(View v) {
//                GPStracker g = new GPStracker(getApplicationContext());
//                Location l = g.getLocation();
//
//                if(l == null) {
//
//                    Toast.makeText(getApplicationContext(), "failed", Toast.LENGTH_LONG).show();
//
//                }else{
//                    double lat = l.getLatitude(); //49.278239
//                    double lon =  l.getLongitude(); //-122.909372;
//
//                    if (passedThrough == false){
//                        ilat = l.getLatitude();
//                        ilon = l.getLongitude();
//                        passedThrough = true;
//
//                    }
//
//                    Location locationA = new Location("point A");
//                    locationA.setLatitude(ilat);
//                    locationA.setLongitude(ilon);
//                    Location locationB = new Location("point B");
//                    locationB.setLatitude(lat);
//                    locationB.setLongitude(lon);
//
//                    float distance = locationA.distanceTo(locationB);
//
//                    if(distance > 5) {
//
////                        AlertDialog.Builder myAlert = new AlertDialog.Builder(MenuActivityKaku.this);
////                        myAlert.setMessage("Distance reached")
////                                .setPositiveButton("Goodjob!", new DialogInterface.OnClickListener() {
////                                            @Override
////                                            public void onClick(DialogInterface dialog, int which) {
////                                                dialog.dismiss();
////                                            }
////                                        }
////                                )
////                                .create();
////                        myAlert.show();
//                        Toast.makeText(getApplicationContext(), "distance reached", Toast.LENGTH_LONG).show();
//                    }
////                    AlertDialog.Builder myAlert = new AlertDialog.Builder(MenuActivityKaku.this);
////                    myAlert.setMessage("LAT: "+String.valueOf(lat)+" \n LON: " + String.valueOf(lon))
////                            .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
////                                        @Override
////                                        public void onClick(DialogInterface dialog, int which) {
////                                            dialog.dismiss();
////                                        }
////                                    }
////                            )
////                            .create();
////                    myAlert.show();
//                    Toast.makeText(getApplicationContext(), "LAT: "+lat+" \n LON: "+lon,Toast.LENGTH_LONG).show();
//                }
//            }
//        });
//    }
}
