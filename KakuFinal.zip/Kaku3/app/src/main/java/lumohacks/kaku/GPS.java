package lumohacks.kaku;

        import android.Manifest;
        import android.content.Intent;
        import android.location.Location;
        import android.support.v4.app.ActivityCompat;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.Toast;

public class GPS extends AppCompatActivity {
    boolean passedThrough = false;
    double ilat = 0; double ilon = 0;

    public Button returnButton;

    Button btnGetLoc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gps);
        btnGetLoc = (Button) findViewById(R.id.btnGetLoc);
        ActivityCompat.requestPermissions(GPS.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},123);
        btnGetLoc.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                GPStracker g = new GPStracker(getApplicationContext());
                Location l = g.getLocation();

                if(l == null) {
                    Toast.makeText(getApplicationContext(), "failed", Toast.LENGTH_LONG).show();

                }else{
                    double lat = l.getLatitude(); //49.278239
                    double lon =  l.getLongitude(); //-122.909372;

                    if (passedThrough == false){
                        ilat = l.getLatitude();
                        ilon = l.getLongitude();
                        passedThrough = true;

                    }

                    Location locationA = new Location("point A");
                    locationA.setLatitude(ilat);
                    locationA.setLongitude(ilon);
                    Location locationB = new Location("point B");
                    locationB.setLatitude(lat);
                    locationB.setLongitude(lon);

                    float distance = locationA.distanceTo(locationB);

                    if(distance > 5) {
                        Toast.makeText(getApplicationContext(), "distance reached", Toast.LENGTH_LONG).show();
                    }
                    Toast.makeText(getApplicationContext(), "LAT: "+lat+" \n LON: "+lon,Toast.LENGTH_LONG).show();
                }
            }
        });
        returnButton();
    }



    public void returnButton()
    {
        returnButton = (Button)findViewById(R.id.settingsButton);

        returnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent returnScreen = new Intent(GPS.this,MenuActivityKaku.class);
                startActivity(returnScreen);
            }
        });
    }
}