package lumohacks.kaku;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.io.FileOutputStream;

public class ObjectivesActivity extends AppCompatActivity {
    public Button returnButton;
    public Button mealButton;
    public Button showerButton;
    public Button socialButton;

    final String fileName = "kakuConfigNew.txt";
    String configContents = "";

    float currency = 0;
    float objective = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_objectives);


        returnButton();
        mealButton();
        showerButton();
        socialButton();
    }

    /* Save Data */
    public void saveFile(String file, String configContents)
    {
        try {
            FileOutputStream fos = openFileOutput(file, Context.MODE_PRIVATE);
            fos.write(configContents.getBytes());
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* Return Button */
    public void returnButton()
    {

        returnButton = (Button)findViewById(R.id.settingsButton);

        returnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                configContents = String.valueOf(currency) + " " + String.valueOf(objective);
                saveFile(fileName, configContents);
                Intent returnScreen = new Intent(ObjectivesActivity.this,MenuActivityKaku.class);
                startActivity(returnScreen);
            }
        });
    }

    /* Meal Button */
    public void mealButton()
    {
        mealButton = (Button)findViewById(R.id.mealButton);

        mealButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mealButtonCalled();
            }
        });
    }

    public void mealButtonCalled() {
        AlertDialog.Builder myAlert = new AlertDialog.Builder(this);
        myAlert.setMessage("I ate a meal")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                currency = currency + 10;
                                objective = objective + 1;
                                dialog.dismiss();
                            }
                        }
                )
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        }
                )
                .create();
        myAlert.show();
    }

    /* Shower Button */
    public void showerButton()
    {
        showerButton = (Button)findViewById(R.id.showerButton);

        showerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                showerButtonCalled();
            }
        });
    }
    public void showerButtonCalled() {
        AlertDialog.Builder myAlert = new AlertDialog.Builder(this);
        myAlert.setMessage("I took a bath/shower")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                currency = currency + 10;
                                objective = objective + 1;
                                dialog.dismiss();
                            }
                        }
                )
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        }
                )
                .create();
        myAlert.show();
    }

    /* Social Button */
    public void socialButton()
    {
        socialButton = (Button)findViewById(R.id.socialButton);

        socialButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                socialButtonCalled();
            }
        });

    }
    public void socialButtonCalled() {
        AlertDialog.Builder myAlert = new AlertDialog.Builder(this);
        myAlert.setMessage("I talked to one person")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                currency = currency + 10;
                                objective = objective + 1;
                                dialog.dismiss();
                            }
                        }
                )
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        }
                )
                .create();
        myAlert.show();
    }
}